//This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

int main()
{
    int dimension = 0;
    int inputVariables = 0;
    int largestSum = 0;
    int currentSum = 0;

    cin >> dimension;

    int** matrix = new int* [dimension];

    for (int i = 0; i < dimension; i++) {
        matrix[i] = new int[dimension];
    }

    for (int i = 0; i < dimension; i++) {
        for (int j = 0; j < dimension; j++) {
            cin >> inputVariables;
            matrix[i][j] = inputVariables;
        }
    }

   
    for (int subMatrix = 2; subMatrix <= dimension; subMatrix++) {
        for (int i = 0; i < dimension - subMatrix + 1; i++) {
            for (int j = 0; j < dimension - subMatrix + 1; j++) {
                currentSum = 0;
                for (int k = i; k < subMatrix + i; k++) {
                    for (int l = j; l < subMatrix + j; l++) {
                        currentSum += matrix[k][l];
                    }
                }
                if (currentSum > largestSum) {
                    largestSum = currentSum;
                }
            }
        }
    }

    cout << largestSum;

    delete [] matrix;

    return(0);
}


