//This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>

using namespace std;

void outputSize1(vector<int> inputVecList, string singles[], string tens[], string teens[], string hundreds, string thousands) {
    cout << singles[inputVecList[0]];
}

void outputSize2(vector<int> inputVecList, string singles[], string tens[], string teens[], string hundreds, string thousands, int increase) {
    if (0 < inputVecList[0 + increase] < 2) {
        cout << teens[inputVecList[1 + increase]];
    }
    if (inputVecList[0 + increase] >= 2) {
        if (inputVecList[1 + increase] == 0) {
            cout << tens[inputVecList[0 + increase] - 1];
        }
        else {
            cout << tens[inputVecList[0 + increase] - 1] << " " << singles[inputVecList[1] + increase];
        }

    }

}

void outputSize3(vector<int> inputVecList, string singles[], string tens[], string teens[], string hundreds, string thousands) {
    outputSize1(inputVecList, singles, tens, teens, hundreds, thousands);
    cout << " " + hundreds + " and ";
    outputSize2(inputVecList, singles, tens, teens, hundreds, thousands, 1);

}

int main()
{

    string singles[10] = { "Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine" };
    string tens[9] = { "Ten","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety" };
    string teens[10] = { "Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen" };
    string hundreds = "Hundred";
    string thousands = "Thousand";

    string inputString;
    vector<int> inputVecList;

    //string outputString;

    string tempString;
    int tempInt = 0;

    cin >> inputString;

    for (int i = 0; i < inputString.size(); i++) {
        tempString = inputString[i];
        tempInt = stoi(tempString);
        inputVecList.push_back(tempInt);
    }

    /*for (int i = 0; i < inputVecList.size(); i++) {

        if (inputVecList.size() == 1) {
            cout << singles[inputVecList[i]];
        }

        if (inputVecList.size() == 2) {
            if (inputVecList[i] < 2) {

            }
        }

    }*/

    if (inputVecList.size() == 1) {
        //cout << singles[inputVecList[0]];
        outputSize1(inputVecList, singles, tens, teens, hundreds, thousands);
    }

    if (inputVecList.size() == 2) {
        /*if (inputVecList[0] < 2) {
            cout << teens[inputVecList[1]];
        }*/
        outputSize2(inputVecList, singles, tens, teens, hundreds, thousands, 0);
    }

    /*if (inputVecList.size() == 2) {
        if (inputVecList[0] >= 2) {
            if (inputVecList[1] == 0) {
                cout << tens[inputVecList[0] - 1];
            }
            else {
                cout << tens[inputVecList[0] - 1] << " " << singles[inputVecList[1]];
            }

        }
    }*/

    if (inputVecList.size() == 3) {
        outputSize3(inputVecList, singles, tens, teens, hundreds, thousands);
    }

}


